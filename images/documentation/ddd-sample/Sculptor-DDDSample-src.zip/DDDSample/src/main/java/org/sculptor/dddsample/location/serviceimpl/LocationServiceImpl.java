package org.sculptor.dddsample.location.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

/**
 * Implementation of LocationService.
 */
@Service("locationService")
public class LocationServiceImpl extends LocationServiceImplBase {
    private static final Log LOG = LogFactory.getLog(LocationServiceImpl.class);

    public LocationServiceImpl() {
    }
}
