package org.sculptor.dddsample.carrier.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

/**
 * Implementation of CarrierService.
 */
@Service("carrierService")
public class CarrierServiceImpl extends CarrierServiceImplBase {
    private static final Log LOG = LogFactory.getLog(CarrierServiceImpl.class);

    public CarrierServiceImpl() {
    }
}
