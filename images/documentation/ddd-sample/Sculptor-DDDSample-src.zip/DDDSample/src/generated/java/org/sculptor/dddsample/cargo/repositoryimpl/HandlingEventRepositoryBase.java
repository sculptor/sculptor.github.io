package org.sculptor.dddsample.cargo.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByQueryAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.cargo.domain.HandlingEvent;
import org.sculptor.dddsample.cargo.domain.HandlingEventRepository;
import org.sculptor.dddsample.cargo.domain.TrackingId;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * Generated base class for implementation of Repository for HandlingEvent
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("handlingEventRepository")
 * </pre>
 *
 */
public abstract class HandlingEventRepositoryBase
    implements HandlingEventRepository {

    /**
     * Reference to the access object factory.
     */
    private HandlingEventAccessFactory handlingEventAccessFactory;

    public HandlingEventRepositoryBase() {
    }

    protected HandlingEventAccessFactory getHandlingEventAccessFactory() {
        return handlingEventAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setHandlingEventAccessFactory(
        HandlingEventAccessFactory handlingEventAccessFactory) {
        this.handlingEventAccessFactory = handlingEventAccessFactory;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess}
     */
    public HandlingEvent save(HandlingEvent entity) {
        SaveAccess<HandlingEvent> ao =
            handlingEventAccessFactory.createSaveAccess();
        ao.setEntity(entity);

        ao.execute();

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByQueryAccess}
     */
    protected List<HandlingEvent> findByQuery(String query,
        Map<String, Object> parameters) {
        FindByQueryAccess<HandlingEvent> ao =
            handlingEventAccessFactory.createFindByQueryAccess();
        ao.setQuery(query);
        ao.setParameters(parameters);

        ao.execute();

        return ao.getResult();
    }

    public abstract List<HandlingEvent> findEventsForCargo(
        TrackingId trackingId);
}
