package org.sculptor.dddsample.location.domain;

import org.sculptor.dddsample.location.exception.LocationNotFoundException;

import java.util.List;

/**
 * Generated interface for Repository for Location
 */
public interface LocationRepository {
    public static final String BEAN_ID = "locationRepository";

    public Location find(UnLocode unLocode) throws LocationNotFoundException;

    public List<Location> findAll();
}
