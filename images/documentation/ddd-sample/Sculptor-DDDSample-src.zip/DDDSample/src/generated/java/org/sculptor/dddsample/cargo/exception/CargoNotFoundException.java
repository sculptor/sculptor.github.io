package org.sculptor.dddsample.cargo.exception;

import org.fornax.cartridges.sculptor.framework.errorhandling.ApplicationException;

import java.io.Serializable;

public class CargoNotFoundException extends ApplicationException {
    private static final String ERROR_CODE =
        CargoNotFoundException.class.getName();

    public CargoNotFoundException(String m) {
        super(ERROR_CODE, m);
    }

    public CargoNotFoundException(String m, Serializable messageParameter) {
        super(ERROR_CODE, m);
        setMessageParameters(new Serializable[] { messageParameter });
    }

    public CargoNotFoundException(String m, Serializable[] messageParameters) {
        super(ERROR_CODE, m);
        setMessageParameters(messageParameters);
    }
}
