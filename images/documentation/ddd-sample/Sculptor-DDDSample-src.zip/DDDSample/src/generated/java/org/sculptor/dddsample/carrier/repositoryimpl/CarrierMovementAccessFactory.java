package org.sculptor.dddsample.carrier.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * <p>
 * Abstract Factory that defines factory methods for CarrierMovement
 * access objects. It holds the concrete factory, which is dependency
 * injected. It also holds the {@link javax.persistence.EntityManager},
 * which is typically injected into each access object by the concrete
 * factory.
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
public abstract class CarrierMovementAccessFactory {
    private EntityManager entityManager;

    /**
     * Dependency injection
     */
    @PersistenceContext
    protected void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    protected EntityManager getEntityManager() {
        return entityManager;
    }

    protected Class getPersistentClass() {
        return CarrierMovement.class;
    }

    public abstract FindByKeysAccess<CarrierMovement> createFindByKeysAccess();

    public abstract SaveAccess<CarrierMovement> createSaveAccess();
}
