package org.sculptor.dddsample.cargo.domain;

import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;

import java.util.List;

/**
 * Generated interface for Repository for Cargo
 */
public interface CargoRepository {
    public static final String BEAN_ID = "cargoRepository";

    public Cargo find(TrackingId trackingId) throws CargoNotFoundException;

    public Cargo find(TrackingId trackingId, boolean loadDeliveryHistory)
        throws CargoNotFoundException;

    public List<Cargo> findAll();

    public Cargo save(Cargo entity);

    public TrackingId nextTrackingId();

    public void detachItineray(Cargo cargo);
}
