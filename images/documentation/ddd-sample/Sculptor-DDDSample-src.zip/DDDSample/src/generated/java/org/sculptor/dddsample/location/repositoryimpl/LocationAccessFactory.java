package org.sculptor.dddsample.location.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;

import org.sculptor.dddsample.location.domain.Location;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * <p>
 * Abstract Factory that defines factory methods for Location
 * access objects. It holds the concrete factory, which is dependency
 * injected. It also holds the {@link javax.persistence.EntityManager},
 * which is typically injected into each access object by the concrete
 * factory.
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
public abstract class LocationAccessFactory {
    private EntityManager entityManager;

    /**
     * Dependency injection
     */
    @PersistenceContext
    protected void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    protected EntityManager getEntityManager() {
        return entityManager;
    }

    protected Class getPersistentClass() {
        return Location.class;
    }

    public abstract FindAllAccess<Location> createFindAllAccess();

    public abstract FindByKeysAccess<Location> createFindByKeysAccess();
}
