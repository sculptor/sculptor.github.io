package org.sculptor.dddsample.carrier.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;

/**
 * Generated interface for the Service CarrierService.
 */
public interface CarrierService {
    public static final String BEAN_ID = "carrierService";

    public CarrierMovement find(ServiceContext ctx,
        CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException;

    public CarrierMovement save(ServiceContext ctx, CarrierMovement entity);
}
