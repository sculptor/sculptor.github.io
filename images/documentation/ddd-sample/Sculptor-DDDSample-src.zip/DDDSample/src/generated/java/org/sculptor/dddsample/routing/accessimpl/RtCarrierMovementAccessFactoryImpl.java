package org.sculptor.dddsample.routing.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaSaveAccessImpl;

import org.sculptor.dddsample.routing.domain.RtCarrierMovement;
import org.sculptor.dddsample.routing.repositoryimpl.RtCarrierMovementAccessFactory;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates RtCarrierMovement access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("rtCarrierMovementAccessFactory")
public class RtCarrierMovementAccessFactoryImpl
    extends RtCarrierMovementAccessFactory {
    public SaveAccess<RtCarrierMovement> createSaveAccess() {
        JpaSaveAccessImpl<RtCarrierMovement> ao =
            new JpaSaveAccessImpl<RtCarrierMovement>();
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
