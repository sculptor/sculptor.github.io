package org.sculptor.dddsample.cargo.domain;

import java.util.List;

/**
 * Generated interface for Repository for HandlingEvent
 */
public interface HandlingEventRepository {
    public static final String BEAN_ID = "handlingEventRepository";

    public HandlingEvent save(HandlingEvent entity);

    /**
    * All handling events for this cargo, ordered by completion time.
    */
    public List<HandlingEvent> findEventsForCargo(TrackingId trackingId);
}
