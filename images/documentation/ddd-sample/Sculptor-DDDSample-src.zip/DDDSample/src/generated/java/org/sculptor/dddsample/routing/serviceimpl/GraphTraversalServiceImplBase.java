package org.sculptor.dddsample.routing.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.sculptor.dddsample.routing.domain.RtCarrierMovementRepository;
import org.sculptor.dddsample.routing.domain.RtLocationRepository;
import org.sculptor.dddsample.routing.serviceapi.GraphTraversalService;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of GraphTraversalService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("graphTraversalService")
 * </pre>
 *
 */
public abstract class GraphTraversalServiceImplBase
    implements GraphTraversalService {
    private static final Log LOG =
        LogFactory.getLog(GraphTraversalServiceImplBase.class);
    private RtCarrierMovementRepository rtCarrierMovementRepository;
    private RtLocationRepository rtLocationRepository;

    public GraphTraversalServiceImplBase() {
    }

    protected RtCarrierMovementRepository getRtCarrierMovementRepository() {
        return rtCarrierMovementRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRtCarrierMovementRepository(
        RtCarrierMovementRepository rtCarrierMovementRepository) {
        this.rtCarrierMovementRepository = rtCarrierMovementRepository;
    }

    protected RtLocationRepository getRtLocationRepository() {
        return rtLocationRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRtLocationRepository(
        RtLocationRepository rtLocationRepository) {
        this.rtLocationRepository = rtLocationRepository;
    }
}
