package org.sculptor.dddsample.cargo.repositoryimpl;

import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;

/**
 * <p>
 * Access object for CargoRepository.find.
 * </p>
 * <p>
 * Command design pattern. Set input parameters with the
 * setter methods. {@link #execute Execute}
 * the command and retrieve the {@link #getResult result}.
 * </p>
 *
 */
public interface FindCargoAccessObject {
    void setTrackingId(TrackingId trackingId);

    void execute() throws CargoNotFoundException;

    /**
     * The result of the command.
     */
    Cargo getResult();
}
