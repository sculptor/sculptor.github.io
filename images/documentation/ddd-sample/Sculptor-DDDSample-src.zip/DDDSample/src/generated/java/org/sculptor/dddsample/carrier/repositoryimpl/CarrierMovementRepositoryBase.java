package org.sculptor.dddsample.carrier.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.domain.CarrierMovementRepository;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Generated base class for implementation of Repository for CarrierMovement
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("carrierMovementRepository")
 * </pre>
 *
 */
public abstract class CarrierMovementRepositoryBase
    implements CarrierMovementRepository {

    /**
     * Reference to the access object factory.
     */
    private CarrierMovementAccessFactory carrierMovementAccessFactory;

    public CarrierMovementRepositoryBase() {
    }

    protected CarrierMovementAccessFactory getCarrierMovementAccessFactory() {
        return carrierMovementAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCarrierMovementAccessFactory(
        CarrierMovementAccessFactory carrierMovementAccessFactory) {
        this.carrierMovementAccessFactory = carrierMovementAccessFactory;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    protected Map<Object, CarrierMovement> findByKeys(Set keys) {
        FindByKeysAccess<CarrierMovement> ao =
            carrierMovementAccessFactory.createFindByKeysAccess();
        ao.setKeys(keys);

        ao.setKeyPropertyName("carrierMovementId");

        ao.setRestrictionPropertyName("carrierMovementId.identifier");

        ao.execute();

        return ao.getResult();
    }

    /**
     * Find by the natural keys.
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    protected Map<CarrierMovementId, CarrierMovement> findByNaturalKeys(
        Set<CarrierMovementId> naturalKeys) {
        Map<Object, CarrierMovement> result1 = findByKeys(naturalKeys);

        // convert to Map with CarrierMovementId key type
        Map<CarrierMovementId, CarrierMovement> result2 =
            new HashMap<CarrierMovementId, CarrierMovement>();
        for (Map.Entry<Object, CarrierMovement> e : result1.entrySet()) {
            result2.put((CarrierMovementId) e.getKey(), e.getValue());
        }
        return result2;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess}
     */
    public CarrierMovement save(CarrierMovement entity) {
        SaveAccess<CarrierMovement> ao =
            carrierMovementAccessFactory.createSaveAccess();
        ao.setEntity(entity);

        ao.execute();

        return ao.getResult();
    }

    public abstract CarrierMovement find(CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException;
}
