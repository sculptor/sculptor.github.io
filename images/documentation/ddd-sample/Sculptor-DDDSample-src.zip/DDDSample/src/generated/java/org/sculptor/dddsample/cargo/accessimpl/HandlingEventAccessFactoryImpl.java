package org.sculptor.dddsample.cargo.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByQueryAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindByQueryAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaSaveAccessImpl;

import org.sculptor.dddsample.cargo.domain.HandlingEvent;
import org.sculptor.dddsample.cargo.repositoryimpl.HandlingEventAccessFactory;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates HandlingEvent access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("handlingEventAccessFactory")
public class HandlingEventAccessFactoryImpl extends HandlingEventAccessFactory {
    public SaveAccess<HandlingEvent> createSaveAccess() {
        JpaSaveAccessImpl<HandlingEvent> ao =
            new JpaSaveAccessImpl<HandlingEvent>();
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindByQueryAccess<HandlingEvent> createFindByQueryAccess() {
        JpaFindByQueryAccessImpl<HandlingEvent> ao =
            new JpaFindByQueryAccessImpl<HandlingEvent>();
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
