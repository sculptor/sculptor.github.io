package org.sculptor.dddsample.location.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.validator.NotNull;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
@javax.persistence.Embeddable
 * </pre>
 *
 */
@MappedSuperclass
public abstract class UnLocodeBase extends AbstractDomainObject {
    @Column(name = "", nullable = false, length = 100, unique = true)
    @NotNull
    private String unlocode;

    protected UnLocodeBase() {
    }

    public UnLocodeBase(String unlocode) {
        super();
        Validate.notNull(unlocode);
        this.unlocode = unlocode;
    }

    public String getUnlocode() {
        return unlocode;
    }

    /**
     * Creates a copy of this instance, but with another unlocode.
     */
    public UnLocode withUnlocode(String unlocode) {
        if (EqualsHelper.equals(unlocode, getUnlocode())) {
            return (UnLocode) this;
        }
        return new UnLocode(unlocode);
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getUnlocode}
     */
    public Object getKey() {
        return getUnlocode();
    }
}
