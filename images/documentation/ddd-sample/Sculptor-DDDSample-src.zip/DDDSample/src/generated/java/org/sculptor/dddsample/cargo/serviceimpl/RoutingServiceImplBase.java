package org.sculptor.dddsample.cargo.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.serviceapi.RoutingService;
import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;
import org.sculptor.dddsample.carrier.serviceapi.CarrierService;
import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;
import org.sculptor.dddsample.location.serviceapi.LocationService;
import org.sculptor.dddsample.routing.domain.TransitPath;
import org.sculptor.dddsample.routing.serviceapi.GraphTraversalService;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Generated base class for implementation of RoutingService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("routingService")
 * </pre>
 *
 */
public abstract class RoutingServiceImplBase implements RoutingService {
    private static final Log LOG =
        LogFactory.getLog(RoutingServiceImplBase.class);
    private GraphTraversalService graphTraversalService;
    private LocationService locationService;
    private CarrierService carrierService;

    public RoutingServiceImplBase() {
    }

    protected GraphTraversalService getGraphTraversalService() {
        return graphTraversalService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setGraphTraversalService(
        GraphTraversalService graphTraversalService) {
        this.graphTraversalService = graphTraversalService;
    }

    protected LocationService getLocationService() {
        return locationService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setLocationService(LocationService locationService) {
        this.locationService = locationService;
    }

    protected CarrierService getCarrierService() {
        return carrierService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCarrierService(CarrierService carrierService) {
        this.carrierService = carrierService;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.routing.serviceapi.GraphTraversalService#findShortestPath}
     */
    protected List<TransitPath> findShortestPath(ServiceContext ctx,
        String originUnLocode, String destinationUnLocode) {
        return graphTraversalService.findShortestPath(ctx, originUnLocode,
            destinationUnLocode);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.location.serviceapi.LocationService#find}
     */
    protected Location findLocation(ServiceContext ctx, UnLocode unLocode)
        throws LocationNotFoundException {
        return locationService.find(ctx, unLocode);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.carrier.serviceapi.CarrierService#find}
     */
    protected CarrierMovement findCarrierMovement(ServiceContext ctx,
        CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException {
        return carrierService.find(ctx, carrierMovementId);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.carrier.serviceapi.CarrierService#save}
     */
    protected CarrierMovement saveCarrierMovement(ServiceContext ctx,
        CarrierMovement entity) {
        return carrierService.save(ctx, entity);

    }
}
