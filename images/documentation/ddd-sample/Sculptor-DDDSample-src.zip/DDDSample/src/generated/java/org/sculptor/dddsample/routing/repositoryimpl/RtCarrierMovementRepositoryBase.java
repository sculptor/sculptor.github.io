package org.sculptor.dddsample.routing.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.routing.domain.RtCarrierMovement;
import org.sculptor.dddsample.routing.domain.RtCarrierMovementRepository;
import org.sculptor.dddsample.routing.domain.RtLocationRepository;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of Repository for RtCarrierMovement
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("rtCarrierMovementRepository")
 * </pre>
 *
 */
public abstract class RtCarrierMovementRepositoryBase
    implements RtCarrierMovementRepository {

    /**
     * Reference to the access object factory.
     */
    private RtCarrierMovementAccessFactory rtCarrierMovementAccessFactory;
    private RtLocationRepository rtLocationRepository;

    public RtCarrierMovementRepositoryBase() {
    }

    protected RtCarrierMovementAccessFactory getRtCarrierMovementAccessFactory() {
        return rtCarrierMovementAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRtCarrierMovementAccessFactory(
        RtCarrierMovementAccessFactory rtCarrierMovementAccessFactory) {
        this.rtCarrierMovementAccessFactory = rtCarrierMovementAccessFactory;
    }

    protected RtLocationRepository getRtLocationRepository() {
        return rtLocationRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRtLocationRepository(
        RtLocationRepository rtLocationRepository) {
        this.rtLocationRepository = rtLocationRepository;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess}
     */
    protected RtCarrierMovement save(RtCarrierMovement entity) {
        SaveAccess<RtCarrierMovement> ao =
            rtCarrierMovementAccessFactory.createSaveAccess();
        ao.setEntity(entity);

        ao.execute();

        return ao.getResult();
    }

    public abstract void storeCarrierMovementId(String cmId, String from,
        String to);
}
