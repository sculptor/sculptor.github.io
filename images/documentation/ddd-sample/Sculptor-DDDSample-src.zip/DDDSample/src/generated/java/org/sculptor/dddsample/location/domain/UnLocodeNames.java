package org.sculptor.dddsample.location.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.location.domain.UnLocode}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface UnLocodeNames {
    public static final String UNLOCODE = "unlocode";
}
