package org.sculptor.dddsample.cargo.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.Type;
import org.hibernate.validator.NotNull;

import org.joda.time.DateTime;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.location.domain.Location;

import java.lang.reflect.Field;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
@javax.persistence.Entity
@javax.persistence.Table(name = "HANDLINGEVENT")
 * </pre>
 *
 */
@MappedSuperclass
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public abstract class HandlingEventBase extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "COMPLETIONTIME", nullable = false)
    @Type(type = "org.joda.time.contrib.hibernate.PersistentDateTime")
    @NotNull
    private DateTime completionTime;
    @Column(name = "REGISTRATIONTIME", nullable = false)
    @Type(type = "org.joda.time.contrib.hibernate.PersistentDateTime")
    @NotNull
    private DateTime registrationTime;
    @Column(name = "UUID", nullable = false, length = 255, unique = true)
    private String uuid;
    @Column(name = "TYPE", nullable = false)
    @Type(type = "Type")
    @NotNull
    private org.sculptor.dddsample.cargo.domain.Type type;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CARRIERMOVEMENT")
    @ForeignKey(name = "FK_HANDLINGEVENT_CARRIERMOVEMENT")
    private CarrierMovement carrierMovement;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "LOCATION")
    @ForeignKey(name = "FK_HANDLINGEVENT_LOCATION")
    @NotNull
    private Location location;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "CARGO")
    @ForeignKey(name = "FK_HANDLINGEVENT_CARGO")
    @NotNull
    private Cargo cargo;

    protected HandlingEventBase() {
    }

    public HandlingEventBase(DateTime completionTime,
        DateTime registrationTime,
        org.sculptor.dddsample.cargo.domain.Type type,
        CarrierMovement carrierMovement, Location location, Cargo cargo) {
        super();
        Validate.notNull(completionTime);
        this.completionTime = completionTime;
        Validate.notNull(registrationTime);
        this.registrationTime = registrationTime;
        this.type = type;
        this.carrierMovement = carrierMovement;
        this.location = location;
        this.cargo = cargo;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public DateTime getCompletionTime() {
        return completionTime;
    }

    /**
     * Creates a copy of this instance, but with another completionTime.
     */
    public HandlingEvent withCompletionTime(DateTime completionTime) {
        if (EqualsHelper.equals(completionTime, getCompletionTime())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(completionTime, getRegistrationTime(),
            getType(), getCarrierMovement(), getLocation(), getCargo());
    }

    public DateTime getRegistrationTime() {
        return registrationTime;
    }

    /**
     * Creates a copy of this instance, but with another registrationTime.
     */
    public HandlingEvent withRegistrationTime(DateTime registrationTime) {
        if (EqualsHelper.equals(registrationTime, getRegistrationTime())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(getCompletionTime(), registrationTime,
            getType(), getCarrierMovement(), getLocation(), getCargo());
    }

    /**
     * This domain object doesn't have a natural key
     * and this random generated identifier is the
     * unique identifier for this domain object.
     */
    public String getUuid() {

        // lazy init of UUID
        if (uuid == null) {
            uuid = java.util.UUID.randomUUID().toString();
        }
        return uuid;
    }

    @SuppressWarnings("unused")
    @PrePersist
    private void initUuid() {
        getUuid();
    }

    public org.sculptor.dddsample.cargo.domain.Type getType() {
        return type;
    }

    /**
     * Creates a copy of this instance, but with another type.
     */
    public HandlingEvent withType(org.sculptor.dddsample.cargo.domain.Type type) {
        if (EqualsHelper.equals(type, getType())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(getCompletionTime(), getRegistrationTime(),
            type, getCarrierMovement(), getLocation(), getCargo());
    }

    public CarrierMovement getCarrierMovement() {
        return carrierMovement;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setCarrierMovement(CarrierMovement carrierMovement) {

        // it must be possible to set null when deleting objects
        if ((carrierMovement != null) && (this.carrierMovement != null) &&
              !this.carrierMovement.equals(carrierMovement)) {
            throw new IllegalArgumentException(
                "Not allowed to change the carrierMovement reference.");
        }
        this.carrierMovement = carrierMovement;
    }

    /**
     * Creates a copy of this instance, but with another carrierMovement.
     */
    public HandlingEvent withCarrierMovement(CarrierMovement carrierMovement) {
        if (EqualsHelper.equals(carrierMovement, getCarrierMovement())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(getCompletionTime(), getRegistrationTime(),
            getType(), carrierMovement, getLocation(), getCargo());
    }

    public Location getLocation() {
        return location;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setLocation(Location location) {

        // it must be possible to set null when deleting objects
        if ((location != null) && (this.location != null) &&
              !this.location.equals(location)) {
            throw new IllegalArgumentException(
                "Not allowed to change the location reference.");
        }
        this.location = location;
    }

    /**
     * Creates a copy of this instance, but with another location.
     */
    public HandlingEvent withLocation(Location location) {
        if (EqualsHelper.equals(location, getLocation())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(getCompletionTime(), getRegistrationTime(),
            getType(), getCarrierMovement(), location, getCargo());
    }

    public Cargo getCargo() {
        return cargo;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setCargo(Cargo cargo) {

        // it must be possible to set null when deleting objects
        if ((cargo != null) && (this.cargo != null) &&
              !this.cargo.equals(cargo)) {
            throw new IllegalArgumentException(
                "Not allowed to change the cargo reference.");
        }
        this.cargo = cargo;
    }

    /**
     * Creates a copy of this instance, but with another cargo.
     */
    public HandlingEvent withCargo(Cargo cargo) {
        if (EqualsHelper.equals(cargo, getCargo())) {
            return (HandlingEvent) this;
        }
        return new HandlingEvent(getCompletionTime(), getRegistrationTime(),
            getType(), getCarrierMovement(), getLocation(), cargo);
    }

    /**
     * This method is used by toString. It specifies what to
     * include in the toString result.
     * @return true if the field is to be included in toString
     */
    protected boolean acceptToString(Field field) {
        if (super.acceptToString(field)) {
            return true;
        } else {
            if (field.getName().equals("type")) {
                return true;
            }
            return false;
        }
    }

    /**
     * This method is used by equals and hashCode.
     * @return {{@link #getUuid}
     */
    public Object getKey() {
        return getUuid();
    }
}
