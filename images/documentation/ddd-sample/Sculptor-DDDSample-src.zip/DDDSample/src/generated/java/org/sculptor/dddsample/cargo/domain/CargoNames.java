package org.sculptor.dddsample.cargo.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.cargo.domain.Cargo}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface CargoNames {
    public static final String ID = "id";
    public static final String CREATEDDATE = "createdDate";
    public static final String CREATEDBY = "createdBy";
    public static final String LASTUPDATED = "lastUpdated";
    public static final String LASTUPDATEDBY = "lastUpdatedBy";
    public static final String VERSION = "version";
    public static final String TRACKINGID = "trackingId";
    public static final String ORIGIN = "origin";
    public static final String DESTINATION = "destination";
    public static final String ITINERARY = "itinerary";
    public static final String EVENTS = "events";
}
