package org.sculptor.dddsample.routing.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.routing.domain.TransitPath}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface TransitPathNames {
    public static final String ID = "id";
    public static final String UUID = "uuid";
    public static final String TRANSITEDGES = "transitEdges";
}
