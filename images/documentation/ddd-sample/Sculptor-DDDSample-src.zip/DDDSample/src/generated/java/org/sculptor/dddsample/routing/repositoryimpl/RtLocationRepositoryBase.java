package org.sculptor.dddsample.routing.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;

import org.sculptor.dddsample.routing.domain.RtLocation;
import org.sculptor.dddsample.routing.domain.RtLocationRepository;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Generated base class for implementation of Repository for RtLocation
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("rtLocationRepository")
 * </pre>
 *
 */
public abstract class RtLocationRepositoryBase implements RtLocationRepository {

    /**
     * Reference to the access object factory.
     */
    private RtLocationAccessFactory rtLocationAccessFactory;

    public RtLocationRepositoryBase() {
    }

    protected RtLocationAccessFactory getRtLocationAccessFactory() {
        return rtLocationAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRtLocationAccessFactory(
        RtLocationAccessFactory rtLocationAccessFactory) {
        this.rtLocationAccessFactory = rtLocationAccessFactory;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess}
     */
    protected List<RtLocation> findAll() {
        FindAllAccess<RtLocation> ao =
            rtLocationAccessFactory.createFindAllAccess();

        ao.execute();

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    public Map<Object, RtLocation> findByKeys(Set keys) {
        FindByKeysAccess<RtLocation> ao =
            rtLocationAccessFactory.createFindByKeysAccess();
        ao.setKeys(keys);

        ao.setKeyPropertyName("unlocode");

        ao.execute();

        return ao.getResult();
    }

    /**
     * Find by the natural keys.
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    public Map<String, RtLocation> findByNaturalKeys(Set<String> naturalKeys) {
        Map<Object, RtLocation> result1 = findByKeys(naturalKeys);

        // convert to Map with String key type
        Map<String, RtLocation> result2 = new HashMap<String, RtLocation>();
        for (Map.Entry<Object, RtLocation> e : result1.entrySet()) {
            result2.put((String) e.getKey(), e.getValue());
        }
        return result2;
    }

    public abstract List<String> listLocations();
}
