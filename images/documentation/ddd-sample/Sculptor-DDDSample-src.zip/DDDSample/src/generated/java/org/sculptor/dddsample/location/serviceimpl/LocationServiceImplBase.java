package org.sculptor.dddsample.location.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.LocationRepository;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;
import org.sculptor.dddsample.location.serviceapi.LocationService;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of LocationService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("locationService")
 * </pre>
 *
 */
public abstract class LocationServiceImplBase implements LocationService {
    private static final Log LOG =
        LogFactory.getLog(LocationServiceImplBase.class);
    private LocationRepository locationRepository;

    public LocationServiceImplBase() {
    }

    protected LocationRepository getLocationRepository() {
        return locationRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setLocationRepository(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.location.domain.LocationRepository#find}
     */
    public Location find(ServiceContext ctx, UnLocode unLocode)
        throws LocationNotFoundException {
        return locationRepository.find(unLocode);

    }
}
