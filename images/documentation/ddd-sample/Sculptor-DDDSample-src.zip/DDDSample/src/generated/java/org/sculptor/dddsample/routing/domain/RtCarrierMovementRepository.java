package org.sculptor.dddsample.routing.domain;


/**
 * Generated interface for Repository for RtCarrierMovement
 */
public interface RtCarrierMovementRepository {
    public static final String BEAN_ID = "rtCarrierMovementRepository";

    public void storeCarrierMovementId(String cmId, String from, String to);
}
