package org.sculptor.dddsample.cargo.domain;

import java.io.Serializable;

/**
 * Enum for StatusCode
 */
public enum StatusCode implements Serializable {
    NOT_RECEIVED,
    IN_PORT,
    ONBOARD_CARRIER,
    CLAIMED,
    UNKNOWN;
    private StatusCode() {
    }

    public String getName() {
        return name();
    }
}
