package org.sculptor.dddsample.location.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;

import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.LocationRepository;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Generated base class for implementation of Repository for Location
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("locationRepository")
 * </pre>
 *
 */
public abstract class LocationRepositoryBase implements LocationRepository {

    /**
     * Reference to the access object factory.
     */
    private LocationAccessFactory locationAccessFactory;

    public LocationRepositoryBase() {
    }

    protected LocationAccessFactory getLocationAccessFactory() {
        return locationAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setLocationAccessFactory(
        LocationAccessFactory locationAccessFactory) {
        this.locationAccessFactory = locationAccessFactory;
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess}
     */
    public List<Location> findAll() {
        FindAllAccess<Location> ao =
            locationAccessFactory.createFindAllAccess();

        ao.execute();

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    protected Map<Object, Location> findByKeys(Set keys) {
        FindByKeysAccess<Location> ao =
            locationAccessFactory.createFindByKeysAccess();
        ao.setKeys(keys);

        ao.setKeyPropertyName("unLocode");

        ao.setRestrictionPropertyName("unLocode.unlocode");

        ao.execute();

        return ao.getResult();
    }

    /**
     * Find by the natural keys.
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess}
     */
    protected Map<UnLocode, Location> findByNaturalKeys(
        Set<UnLocode> naturalKeys) {
        Map<Object, Location> result1 = findByKeys(naturalKeys);

        // convert to Map with UnLocode key type
        Map<UnLocode, Location> result2 = new HashMap<UnLocode, Location>();
        for (Map.Entry<Object, Location> e : result1.entrySet()) {
            result2.put((UnLocode) e.getKey(), e.getValue());
        }
        return result2;
    }

    public abstract Location find(UnLocode unLocode)
        throws LocationNotFoundException;
}
