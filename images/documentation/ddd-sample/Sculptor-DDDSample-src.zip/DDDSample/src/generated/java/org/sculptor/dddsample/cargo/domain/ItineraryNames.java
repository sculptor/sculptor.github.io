package org.sculptor.dddsample.cargo.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.cargo.domain.Itinerary}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface ItineraryNames {
    public static final String ID = "id";
    public static final String UUID = "uuid";
    public static final String CARGO = "cargo";
    public static final String LEGS = "legs";
}
