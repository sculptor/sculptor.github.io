package org.sculptor.dddsample.carrier.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.carrier.domain.CarrierMovementId}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface CarrierMovementIdNames {
    public static final String IDENTIFIER = "identifier";
}
