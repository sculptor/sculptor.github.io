package org.sculptor.dddsample.carrier.domain;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.validator.NotNull;

import org.sculptor.dddsample.location.domain.Location;

import java.lang.reflect.Field;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * A carrier movement is a vessel voyage from one location to another.
 */
@Entity
@Table(name = "CARRIERMOVEMENT", uniqueConstraints = @UniqueConstraint(columnNames =  {
    "CARRIERMOVEMENTID"}
)
)
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public class CarrierMovement extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "identifier",column = @Column(name = "CARRIERMOVEMENTID",nullable = true,length = 100)
        )
    })
    @NotNull
    private CarrierMovementId carrierMovementId;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "FRM")
    @ForeignKey(name = "FK_CARRIERMOVEMENT_FRM")
    @NotNull
    private Location from;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "T")
    @ForeignKey(name = "FK_CARRIERMOVEMENT_T")
    @NotNull
    private Location to;

    protected CarrierMovement() {
    }

    public CarrierMovement(CarrierMovementId carrierMovementId, Location from,
        Location to) {
        super();
        this.carrierMovementId = carrierMovementId;
        this.from = from;
        this.to = to;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public CarrierMovementId getCarrierMovementId() {
        return carrierMovementId;
    }

    public Location getFrom() {
        return from;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setFrom(Location from) {

        // it must be possible to set null when deleting objects
        if ((from != null) && (this.from != null) && !this.from.equals(from)) {
            throw new IllegalArgumentException(
                "Not allowed to change the from reference.");
        }
        this.from = from;
    }

    public Location getTo() {
        return to;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setTo(Location to) {

        // it must be possible to set null when deleting objects
        if ((to != null) && (this.to != null) && !this.to.equals(to)) {
            throw new IllegalArgumentException(
                "Not allowed to change the to reference.");
        }
        this.to = to;
    }

    /**
     * This method is used by toString. It specifies what to
     * include in the toString result.
     * @return true if the field is to be included in toString
     */
    protected boolean acceptToString(Field field) {
        if (super.acceptToString(field)) {
            return true;
        } else {
            if (field.getName().equals("carrierMovementId")) {
                return true;
            }
            return false;
        }
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getCarrierMovementId}
     */
    public Object getKey() {
        return getCarrierMovementId();
    }
}
