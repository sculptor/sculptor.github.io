package org.sculptor.dddsample.routing.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.validator.NotNull;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
*
* Value object representing RtCarrierMovement.
*/
@Entity
@Table(name = "RTCARRIERMOVEMENT")
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public class RtCarrierMovement extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "CARRIERMOVEMENTID", nullable = false, length = 100, unique = true)
    @NotNull
    private String carrierMovementId;
    @ManyToOne(optional = false, cascade =  {
        CascadeType.ALL}
    , fetch = FetchType.EAGER)
    @JoinColumn(name = "FRM")
    @ForeignKey(name = "FK_RTCARRIERMOVEMENT_FRM")
    @NotNull
    private RtLocation from;
    @ManyToOne(optional = false, cascade =  {
        CascadeType.ALL}
    , fetch = FetchType.EAGER)
    @JoinColumn(name = "T")
    @ForeignKey(name = "FK_RTCARRIERMOVEMENT_T")
    @NotNull
    private RtLocation to;

    protected RtCarrierMovement() {
    }

    public RtCarrierMovement(String carrierMovementId, RtLocation from,
        RtLocation to) {
        super();
        Validate.notNull(carrierMovementId);
        this.carrierMovementId = carrierMovementId;
        this.from = from;
        this.to = to;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public String getCarrierMovementId() {
        return carrierMovementId;
    }

    /**
     * Creates a copy of this instance, but with another carrierMovementId.
     */
    public RtCarrierMovement withCarrierMovementId(String carrierMovementId) {
        if (EqualsHelper.equals(carrierMovementId, getCarrierMovementId())) {
            return this;
        }
        return new RtCarrierMovement(carrierMovementId, getFrom(), getTo());
    }

    public RtLocation getFrom() {
        return from;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setFrom(RtLocation from) {

        // it must be possible to set null when deleting objects
        if ((from != null) && (this.from != null) && !this.from.equals(from)) {
            throw new IllegalArgumentException(
                "Not allowed to change the from reference.");
        }
        this.from = from;
    }

    /**
     * Creates a copy of this instance, but with another from.
     */
    public RtCarrierMovement withFrom(RtLocation from) {
        if (EqualsHelper.equals(from, getFrom())) {
            return this;
        }
        return new RtCarrierMovement(getCarrierMovementId(), from, getTo());
    }

    public RtLocation getTo() {
        return to;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setTo(RtLocation to) {

        // it must be possible to set null when deleting objects
        if ((to != null) && (this.to != null) && !this.to.equals(to)) {
            throw new IllegalArgumentException(
                "Not allowed to change the to reference.");
        }
        this.to = to;
    }

    /**
     * Creates a copy of this instance, but with another to.
     */
    public RtCarrierMovement withTo(RtLocation to) {
        if (EqualsHelper.equals(to, getTo())) {
            return this;
        }
        return new RtCarrierMovement(getCarrierMovementId(), getFrom(), to);
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getCarrierMovementId}
     */
    public Object getKey() {
        return getCarrierMovementId();
    }
}
