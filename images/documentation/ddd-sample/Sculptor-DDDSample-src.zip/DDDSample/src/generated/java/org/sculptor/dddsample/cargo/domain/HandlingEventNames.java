package org.sculptor.dddsample.cargo.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.cargo.domain.HandlingEvent}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface HandlingEventNames {
    public static final String ID = "id";
    public static final String COMPLETIONTIME = "completionTime";
    public static final String REGISTRATIONTIME = "registrationTime";
    public static final String UUID = "uuid";
    public static final String TYPE = "type";
    public static final String CARRIERMOVEMENT = "carrierMovement";
    public static final String LOCATION = "location";
    public static final String CARGO = "cargo";
}
