package org.sculptor.dddsample.cargo.domain;

import java.io.Serializable;

/**
 * Enum for Type
 */
public enum Type implements Serializable {
    LOAD(true),
    UNLOAD(true),
    RECEIVE(false),
    CLAIM(false),
    CUSTOMS(false);
    private boolean carrierMovementRequired;

    private Type(boolean carrierMovementRequired) {
        this.carrierMovementRequired = carrierMovementRequired;
    }

    public boolean isCarrierMovementRequired() {
        return carrierMovementRequired;
    }

    public String getName() {
        return name();
    }
}
