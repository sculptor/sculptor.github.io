package org.sculptor.dddsample.routing.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.routing.domain.RtLocation}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface RtLocationNames {
    public static final String ID = "id";
    public static final String UNLOCODE = "unlocode";
}
