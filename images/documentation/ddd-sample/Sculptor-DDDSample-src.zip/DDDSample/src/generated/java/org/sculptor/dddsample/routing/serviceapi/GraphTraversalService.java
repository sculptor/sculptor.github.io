package org.sculptor.dddsample.routing.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.routing.domain.TransitPath;

import java.util.List;

/**
 * Generated interface for the Service GraphTraversalService.
 */
public interface GraphTraversalService {
    public static final String BEAN_ID = "graphTraversalService";

    public List<TransitPath> findShortestPath(ServiceContext ctx,
        String originUnLocode, String destinationUnLocode);
}
