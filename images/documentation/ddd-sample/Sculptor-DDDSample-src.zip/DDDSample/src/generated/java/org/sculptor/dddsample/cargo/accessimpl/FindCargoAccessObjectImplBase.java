package org.sculptor.dddsample.cargo.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaAccessBaseWithException;
import org.fornax.cartridges.sculptor.framework.errorhandling.ApplicationException;

import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;
import org.sculptor.dddsample.cargo.repositoryimpl.FindCargoAccessObject;

/**
 * <p>
 * Generated base class for implementation of Access object for CargoRepository.find.
 * </p>
 * <p>
 * Command design pattern.
 * </p>
 *
 */
public abstract class FindCargoAccessObjectImplBase
    extends JpaAccessBaseWithException implements FindCargoAccessObject {
    private TrackingId trackingId;
    private Cargo result;

    public TrackingId getTrackingId() {
        return trackingId;
    }

    public void setTrackingId(TrackingId trackingId) {
        this.trackingId = trackingId;
    }

    public void execute() throws CargoNotFoundException {
        try {
            super.execute();

        } catch (CargoNotFoundException e) {
            throw e;

        } catch (ApplicationException e) {

            // other ApplicationException not expected, wrap it in a RuntimeException
            throw new RuntimeException(e);
        }
    }

    /**
     * The result of the command.
     */
    public Cargo getResult() {
        return this.result;
    }

    protected void setResult(Cargo result) {
        this.result = result;
    }
}
