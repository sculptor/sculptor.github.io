package org.sculptor.dddsample.cargo.domain;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.validator.NotNull;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.location.domain.Location;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
@javax.persistence.Entity
@javax.persistence.Table(name = "LEG")
 * </pre>
 *
 */
@MappedSuperclass
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public abstract class LegBase extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "UUID", nullable = false, length = 255, unique = true)
    private String uuid;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "CARRIERMOVEMENT")
    @ForeignKey(name = "FK_LEG_CARRIERMOVEMENT")
    @NotNull
    private CarrierMovement carrierMovement;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "FRM")
    @ForeignKey(name = "FK_LEG_FRM")
    @NotNull
    private Location from;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "T")
    @ForeignKey(name = "FK_LEG_T")
    @NotNull
    private Location to;

    protected LegBase() {
    }

    public LegBase(CarrierMovement carrierMovement, Location from, Location to) {
        super();
        this.carrierMovement = carrierMovement;
        this.from = from;
        this.to = to;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    /**
     * This domain object doesn't have a natural key
     * and this random generated identifier is the
     * unique identifier for this domain object.
     */
    public String getUuid() {

        // lazy init of UUID
        if (uuid == null) {
            uuid = java.util.UUID.randomUUID().toString();
        }
        return uuid;
    }

    @SuppressWarnings("unused")
    @PrePersist
    private void initUuid() {
        getUuid();
    }

    public CarrierMovement getCarrierMovement() {
        return carrierMovement;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setCarrierMovement(CarrierMovement carrierMovement) {

        // it must be possible to set null when deleting objects
        if ((carrierMovement != null) && (this.carrierMovement != null) &&
              !this.carrierMovement.equals(carrierMovement)) {
            throw new IllegalArgumentException(
                "Not allowed to change the carrierMovement reference.");
        }
        this.carrierMovement = carrierMovement;
    }

    /**
     * Creates a copy of this instance, but with another carrierMovement.
     */
    public Leg withCarrierMovement(CarrierMovement carrierMovement) {
        if (EqualsHelper.equals(carrierMovement, getCarrierMovement())) {
            return (Leg) this;
        }
        return new Leg(carrierMovement, getFrom(), getTo());
    }

    public Location getFrom() {
        return from;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setFrom(Location from) {

        // it must be possible to set null when deleting objects
        if ((from != null) && (this.from != null) && !this.from.equals(from)) {
            throw new IllegalArgumentException(
                "Not allowed to change the from reference.");
        }
        this.from = from;
    }

    /**
     * Creates a copy of this instance, but with another from.
     */
    public Leg withFrom(Location from) {
        if (EqualsHelper.equals(from, getFrom())) {
            return (Leg) this;
        }
        return new Leg(getCarrierMovement(), from, getTo());
    }

    public Location getTo() {
        return to;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setTo(Location to) {

        // it must be possible to set null when deleting objects
        if ((to != null) && (this.to != null) && !this.to.equals(to)) {
            throw new IllegalArgumentException(
                "Not allowed to change the to reference.");
        }
        this.to = to;
    }

    /**
     * Creates a copy of this instance, but with another to.
     */
    public Leg withTo(Location to) {
        if (EqualsHelper.equals(to, getTo())) {
            return (Leg) this;
        }
        return new Leg(getCarrierMovement(), getFrom(), to);
    }

    /**
     * This method is used by equals and hashCode.
     * @return {{@link #getUuid}
     */
    public Object getKey() {
        return getUuid();
    }
}
