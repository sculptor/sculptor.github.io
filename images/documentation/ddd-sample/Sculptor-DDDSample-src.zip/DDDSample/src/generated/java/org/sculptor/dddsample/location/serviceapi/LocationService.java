package org.sculptor.dddsample.location.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;

/**
 * Generated interface for the Service LocationService.
 */
public interface LocationService {
    public static final String BEAN_ID = "locationService";

    public Location find(ServiceContext ctx, UnLocode unLocode)
        throws LocationNotFoundException;
}
