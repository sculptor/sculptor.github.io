package org.sculptor.dddsample.cargo.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByQueryAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.cargo.domain.HandlingEvent;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * <p>
 * Abstract Factory that defines factory methods for HandlingEvent
 * access objects. It holds the concrete factory, which is dependency
 * injected. It also holds the {@link javax.persistence.EntityManager},
 * which is typically injected into each access object by the concrete
 * factory.
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
public abstract class HandlingEventAccessFactory {
    private EntityManager entityManager;

    /**
     * Dependency injection
     */
    @PersistenceContext
    protected void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    protected EntityManager getEntityManager() {
        return entityManager;
    }

    protected Class getPersistentClass() {
        return HandlingEvent.class;
    }

    public abstract SaveAccess<HandlingEvent> createSaveAccess();

    public abstract FindByQueryAccess<HandlingEvent> createFindByQueryAccess();
}
