package org.sculptor.dddsample.routing.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.routing.domain.TransitEdge}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface TransitEdgeNames {
    public static final String ID = "id";
    public static final String CARRIERMOVEMENTID = "carrierMovementId";
    public static final String FROMUNLOCODE = "fromUnLocode";
    public static final String TOUNLOCODE = "toUnLocode";
    public static final String UUID = "uuid";
}
