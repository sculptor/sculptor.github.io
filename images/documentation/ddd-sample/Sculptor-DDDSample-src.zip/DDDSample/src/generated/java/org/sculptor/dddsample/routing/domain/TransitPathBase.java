package org.sculptor.dddsample.routing.domain;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.IndexColumn;
import org.hibernate.validator.NotNull;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
@javax.persistence.Entity
@javax.persistence.Table(name = "TRANSITPATH")
 * </pre>
 *
 */
@MappedSuperclass
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public abstract class TransitPathBase extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "UUID", nullable = false, length = 255, unique = true)
    private String uuid;
    @OneToMany(cascade =  {
        CascadeType.ALL}
    )
    @JoinColumn(name = "TRANSITPATH")
    @ForeignKey(name = "FK_TRANSITPATH_TRANSITEDGE")
    @IndexColumn(name = "TRANSITEDGE_INDEX")
    @NotNull
    private List<TransitEdge> transitEdges = new ArrayList<TransitEdge>();

    public TransitPathBase() {
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    /**
     * This domain object doesn't have a natural key
     * and this random generated identifier is the
     * unique identifier for this domain object.
     */
    public String getUuid() {

        // lazy init of UUID
        if (uuid == null) {
            uuid = java.util.UUID.randomUUID().toString();
        }
        return uuid;
    }

    @SuppressWarnings("unused")
    @PrePersist
    private void initUuid() {
        getUuid();
    }

    public List<TransitEdge> getTransitEdges() {
        return transitEdges;
    }

    /**
     * Adds an object to the unidirectional to-many
     * association.
     * It is added the collection {@link #getTransitEdges}.
     */
    public void addTransitEdge(TransitEdge transitEdgeElement) {
        this.transitEdges.add(transitEdgeElement);
    }

    /**
     * Removes an object from the unidirectional to-many
     * association.
     * It is removed from the collection {@link #getTransitEdges}.
     */
    public void removeTransitEdge(TransitEdge transitEdgeElement) {
        this.transitEdges.remove(transitEdgeElement);
    }

    /**
     * Removes all object from the unidirectional
     * to-many association.
     * All elements are removed from the collection {@link #getTransitEdges}.
     */
    public void removeAllTransitEdges() {
        this.transitEdges.clear();
    }

    /**
     * This method is used by equals and hashCode.
     * @return {{@link #getUuid}
     */
    public Object getKey() {
        return getUuid();
    }
}
