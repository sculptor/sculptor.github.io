package org.sculptor.dddsample.carrier.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.domain.CarrierMovementRepository;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;
import org.sculptor.dddsample.carrier.serviceapi.CarrierService;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of CarrierService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("carrierService")
 * </pre>
 *
 */
public abstract class CarrierServiceImplBase implements CarrierService {
    private static final Log LOG =
        LogFactory.getLog(CarrierServiceImplBase.class);
    private CarrierMovementRepository carrierMovementRepository;

    public CarrierServiceImplBase() {
    }

    protected CarrierMovementRepository getCarrierMovementRepository() {
        return carrierMovementRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCarrierMovementRepository(
        CarrierMovementRepository carrierMovementRepository) {
        this.carrierMovementRepository = carrierMovementRepository;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.carrier.domain.CarrierMovementRepository#find}
     */
    public CarrierMovement find(ServiceContext ctx,
        CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException {
        return carrierMovementRepository.find(carrierMovementId);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.carrier.domain.CarrierMovementRepository#save}
     */
    public CarrierMovement save(ServiceContext ctx, CarrierMovement entity) {
        return carrierMovementRepository.save(entity);

    }
}
