package org.sculptor.dddsample.cargo.domain;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;

import org.hibernate.validator.NotNull;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityListeners;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
 * </pre>
 *
 */
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public abstract class DeliveryHistoryBase extends AbstractDomainObject {
    @NotNull
    private Set<HandlingEvent> events = new HashSet<HandlingEvent>();

    public DeliveryHistoryBase() {
    }

    public Set<HandlingEvent> getEvents() {
        return events;
    }

    /**
     * Adds an object to the unidirectional to-many
     * association.
     * It is added the collection {@link #getEvents}.
     */
    public void addEvent(HandlingEvent eventElement) {
        this.events.add(eventElement);
    }

    /**
     * Removes an object from the unidirectional to-many
     * association.
     * It is removed from the collection {@link #getEvents}.
     */
    public void removeEvent(HandlingEvent eventElement) {
        this.events.remove(eventElement);
    }

    /**
     * Removes all object from the unidirectional
     * to-many association.
     * All elements are removed from the collection {@link #getEvents}.
     */
    public void removeAllEvents() {
        this.events.clear();
    }
}
