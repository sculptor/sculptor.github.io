package org.sculptor.dddsample.routing.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.routing.domain.RtCarrierMovement}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface RtCarrierMovementNames {
    public static final String ID = "id";
    public static final String CARRIERMOVEMENTID = "carrierMovementId";
    public static final String FROM = "from";
    public static final String TO = "to";
}
