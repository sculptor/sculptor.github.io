package org.sculptor.dddsample.routing.domain;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Generated interface for Repository for RtLocation
 */
public interface RtLocationRepository {
    public static final String BEAN_ID = "rtLocationRepository";

    public List<String> listLocations();

    public Map<Object, RtLocation> findByKeys(Set keys);

    /**
     * Find by the natural keys.
     */
    public Map<String, RtLocation> findByNaturalKeys(Set<String> naturalKeys);
}
