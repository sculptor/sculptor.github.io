package org.sculptor.dddsample.cargo.repositoryimpl;


/**
 * Delete orphaned itineraries - conceptually the responsibility
 * of the Cargo aggregate
 */
public interface DeleteOrphanItineraryAccess {
    void execute();
}
