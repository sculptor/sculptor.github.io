package org.sculptor.dddsample.routing.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindAllAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindByKeysAccessImpl;

import org.sculptor.dddsample.routing.domain.RtLocation;
import org.sculptor.dddsample.routing.repositoryimpl.RtLocationAccessFactory;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates RtLocation access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("rtLocationAccessFactory")
public class RtLocationAccessFactoryImpl extends RtLocationAccessFactory {
    public FindAllAccess<RtLocation> createFindAllAccess() {
        JpaFindAllAccessImpl<RtLocation> ao =
            new JpaFindAllAccessImpl<RtLocation>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindByKeysAccess<RtLocation> createFindByKeysAccess() {
        JpaFindByKeysAccessImpl<RtLocation> ao =
            new JpaFindByKeysAccessImpl<RtLocation>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
