package org.sculptor.dddsample.routing.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.routing.domain.RtCarrierMovement;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * <p>
 * Abstract Factory that defines factory methods for RtCarrierMovement
 * access objects. It holds the concrete factory, which is dependency
 * injected. It also holds the {@link javax.persistence.EntityManager},
 * which is typically injected into each access object by the concrete
 * factory.
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
public abstract class RtCarrierMovementAccessFactory {
    private EntityManager entityManager;

    /**
     * Dependency injection
     */
    @PersistenceContext
    protected void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    protected EntityManager getEntityManager() {
        return entityManager;
    }

    protected Class getPersistentClass() {
        return RtCarrierMovement.class;
    }

    public abstract SaveAccess<RtCarrierMovement> createSaveAccess();
}
