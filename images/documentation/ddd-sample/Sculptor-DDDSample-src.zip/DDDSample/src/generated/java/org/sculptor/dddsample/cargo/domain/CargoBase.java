package org.sculptor.dddsample.cargo.domain;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.domain.Auditable;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.Type;
import org.hibernate.validator.NotNull;

import org.sculptor.dddsample.location.domain.Location;

import java.lang.reflect.Field;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Version;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
@javax.persistence.Entity
@javax.persistence.Table(name = "CARGO"    , uniqueConstraints = @javax.persistence.UniqueConstraint(columnNames={"TRACKINGID"}))
 * </pre>
 *
 */
@MappedSuperclass
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class,
    org.fornax.cartridges.sculptor.framework.domain.AuditListener.class
})
public abstract class CargoBase extends AbstractDomainObject
    implements Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "CREATEDDATE")
    @Type(type = "timestamp")
    private Date createdDate;
    @Column(name = "CREATEDBY", length = 50)
    private String createdBy;
    @Column(name = "LASTUPDATED")
    @Type(type = "timestamp")
    private Date lastUpdated;
    @Column(name = "LASTUPDATEDBY", length = 50)
    private String lastUpdatedBy;
    @Version
    @Column(name = "VERSION")
    private Long version;
    @Embedded
    @AttributeOverrides({@AttributeOverride(name = "identifier",column = @Column(name = "TRACKINGID",nullable = true,length = 100)
        )
    })
    @NotNull
    private TrackingId trackingId;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "ORIGIN")
    @ForeignKey(name = "FK_CARGO_ORIGIN")
    @NotNull
    private Location origin;
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "DESTINATION")
    @ForeignKey(name = "FK_CARGO_DESTINATION")
    @NotNull
    private Location destination;
    @OneToOne(mappedBy = "cargo", cascade =  {
        CascadeType.ALL}
    , fetch = FetchType.EAGER)
    private Itinerary itinerary;
    @OneToMany(mappedBy = "cargo")
    @ForeignKey(name = "FK_CARGO_EVENT_CARGO", inverseName = "FK_CARGO_EVENT_EVENT")
    @NotNull
    private Set<HandlingEvent> events = new HashSet<HandlingEvent>();

    protected CargoBase() {
    }

    public CargoBase(TrackingId trackingId, Location origin,
        Location destination) {
        super();
        this.trackingId = trackingId;
        this.origin = origin;
        this.destination = destination;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public TrackingId getTrackingId() {
        return trackingId;
    }

    public Location getOrigin() {
        return origin;
    }

    public void setOrigin(Location origin) {
        this.origin = origin;
    }

    public Location getDestination() {
        return destination;
    }

    public void setDestination(Location destination) {
        this.destination = destination;
    }

    public Itinerary getItinerary() {
        return itinerary;
    }

    public void setItinerary(Itinerary itinerary) {
        this.itinerary = itinerary;
    }

    public Set<HandlingEvent> getEvents() {
        return events;
    }

    /**
     * Adds an object to the bidirectional many-to-one
     * association in both ends.
     * It is added the collection {@link #getEvents}
     * at this side and the association
     * {@link org.sculptor.dddsample.cargo.domain.HandlingEvent#setCargo}
     * at the opposite side is set.
     */
    public void addEvent(HandlingEvent eventElement) {
        this.events.add(eventElement);
        eventElement.setCargo((Cargo) this);
    }

    /**
     * Removes an object from the bidirectional many-to-one
     * association in both ends.
     * It is removed from the collection {@link #getEvents}
     * at this side and the association
     * {@link org.sculptor.dddsample.cargo.domain.HandlingEvent#setCargo}
     * at the opposite side is cleared (nulled).
     */
    public void removeEvent(HandlingEvent eventElement) {
        this.events.remove(eventElement);
        eventElement.setCargo(null);
    }

    /**
     * Removes all object from the bidirectional
     * many-to-one association in both ends.
     * All elements are removed from the collection {@link #getEvents}
     * at this side and the association
     * {@link org.sculptor.dddsample.cargo.domain.HandlingEvent#setCargo}
     * at the opposite side is cleared (nulled).
     */
    public void removeAllEvents() {
        for (HandlingEvent d : this.events) {
            d.setCargo(null);
        }
        this.events.clear();

    }

    /**
     * This method is used by toString. It specifies what to
     * include in the toString result.
     * @return true if the field is to be included in toString
     */
    protected boolean acceptToString(Field field) {
        if (super.acceptToString(field)) {
            return true;
        } else {
            if (field.getName().equals("trackingId")) {
                return true;
            }
            return false;
        }
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getTrackingId}
     */
    public Object getKey() {
        return getTrackingId();
    }
}
