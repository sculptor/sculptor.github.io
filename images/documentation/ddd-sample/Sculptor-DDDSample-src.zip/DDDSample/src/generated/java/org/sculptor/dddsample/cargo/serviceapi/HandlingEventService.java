package org.sculptor.dddsample.cargo.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.joda.time.DateTime;

import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.domain.Type;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;

/**
 * Generated interface for the Service HandlingEventService.
 */
public interface HandlingEventService {
    public static final String BEAN_ID = "handlingEventService";

    public void register(ServiceContext ctx, DateTime completionTime,
        TrackingId trackingId, CarrierMovementId carrierMovementId,
        UnLocode unlocode, Type type)
        throws CargoNotFoundException, CarrierMovementNotFoundException,
            LocationNotFoundException;
}
