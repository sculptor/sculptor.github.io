package org.sculptor.dddsample.location.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.location.domain.Location}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface LocationNames {
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String CREATEDDATE = "createdDate";
    public static final String CREATEDBY = "createdBy";
    public static final String LASTUPDATED = "lastUpdated";
    public static final String LASTUPDATEDBY = "lastUpdatedBy";
    public static final String UNLOCODE = "unLocode";
}
