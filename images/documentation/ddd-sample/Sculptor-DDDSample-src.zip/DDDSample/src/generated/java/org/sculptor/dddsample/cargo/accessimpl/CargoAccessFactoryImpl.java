package org.sculptor.dddsample.cargo.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByIdAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.PopulateAssociationsAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindAllAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindByIdAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaPopulateAssociationsAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaSaveAccessImpl;

import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.repositoryimpl.CargoAccessFactory;
import org.sculptor.dddsample.cargo.repositoryimpl.DeleteOrphanItineraryAccess;
import org.sculptor.dddsample.cargo.repositoryimpl.FindCargoAccessObject;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates Cargo access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("cargoAccessFactory")
public class CargoAccessFactoryImpl extends CargoAccessFactory {
    public PopulateAssociationsAccess<Cargo> createPopulateAssociationsAccess() {
        JpaPopulateAssociationsAccessImpl<Cargo> ao =
            new JpaPopulateAssociationsAccessImpl<Cargo>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindAllAccess<Cargo> createFindAllAccess() {
        JpaFindAllAccessImpl<Cargo> ao =
            new JpaFindAllAccessImpl<Cargo>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public SaveAccess<Cargo> createSaveAccess() {
        JpaSaveAccessImpl<Cargo> ao = new JpaSaveAccessImpl<Cargo>();
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindByIdAccess<Cargo, Long> createFindByIdAccess() {
        JpaFindByIdAccessImpl<Cargo, Long> ao =
            new JpaFindByIdAccessImpl<Cargo, Long>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindCargoAccessObject createFindCargoAccessObject() {
        FindCargoAccessObjectImpl ao = new FindCargoAccessObjectImpl();
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public DeleteOrphanItineraryAccess createDeleteOrphanItineraryAccess() {
        DeleteOrphanItineraryAccessImpl ao =
            new DeleteOrphanItineraryAccessImpl();
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
