package org.sculptor.dddsample.cargo.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaAccessBase;

import org.sculptor.dddsample.cargo.repositoryimpl.DeleteOrphanItineraryAccess;

/**
 * <p>
 * Generated base class for implementation of Access object for CargoRepository.deleteOrphanItinerary.
 * </p>
 * <p>
 * Command design pattern.
 * </p>
 *
 */
public abstract class DeleteOrphanItineraryAccessImplBase extends JpaAccessBase
    implements DeleteOrphanItineraryAccess {
}
