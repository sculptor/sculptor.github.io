package org.sculptor.dddsample.location.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindAllAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindByKeysAccessImpl;

import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.repositoryimpl.LocationAccessFactory;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates Location access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("locationAccessFactory")
public class LocationAccessFactoryImpl extends LocationAccessFactory {
    public FindAllAccess<Location> createFindAllAccess() {
        JpaFindAllAccessImpl<Location> ao =
            new JpaFindAllAccessImpl<Location>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public FindByKeysAccess<Location> createFindByKeysAccess() {
        JpaFindByKeysAccessImpl<Location> ao =
            new JpaFindByKeysAccessImpl<Location>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
