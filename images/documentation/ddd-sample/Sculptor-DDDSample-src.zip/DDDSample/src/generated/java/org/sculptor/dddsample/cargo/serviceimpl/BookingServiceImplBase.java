package org.sculptor.dddsample.cargo.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.domain.CargoRepository;
import org.sculptor.dddsample.cargo.domain.Itinerary;
import org.sculptor.dddsample.cargo.domain.RouteSpecification;
import org.sculptor.dddsample.cargo.serviceapi.BookingService;
import org.sculptor.dddsample.cargo.serviceapi.RoutingService;
import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;
import org.sculptor.dddsample.location.serviceapi.LocationService;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Generated base class for implementation of BookingService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("bookingService")
 * </pre>
 *
 */
public abstract class BookingServiceImplBase implements BookingService {
    private static final Log LOG =
        LogFactory.getLog(BookingServiceImplBase.class);
    private CargoRepository cargoRepository;
    private LocationService locationService;
    private RoutingService routingService;

    public BookingServiceImplBase() {
    }

    protected CargoRepository getCargoRepository() {
        return cargoRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCargoRepository(CargoRepository cargoRepository) {
        this.cargoRepository = cargoRepository;
    }

    protected LocationService getLocationService() {
        return locationService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setLocationService(LocationService locationService) {
        this.locationService = locationService;
    }

    protected RoutingService getRoutingService() {
        return routingService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setRoutingService(RoutingService routingService) {
        this.routingService = routingService;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.location.serviceapi.LocationService#find}
     */
    protected Location findLocation(ServiceContext ctx, UnLocode unLocode)
        throws LocationNotFoundException {
        return locationService.find(ctx, unLocode);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.cargo.serviceapi.RoutingService#fetchRoutesForSpecification}
     */
    protected List<Itinerary> fetchRoutes(ServiceContext ctx,
        RouteSpecification routeSpecification) throws LocationNotFoundException {
        return routingService.fetchRoutesForSpecification(ctx,
            routeSpecification);

    }
}
