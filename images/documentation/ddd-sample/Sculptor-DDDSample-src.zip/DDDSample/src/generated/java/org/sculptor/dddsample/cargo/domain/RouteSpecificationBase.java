package org.sculptor.dddsample.cargo.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.validator.NotNull;

import org.joda.time.DateTime;

import org.sculptor.dddsample.location.domain.Location;

import javax.persistence.EntityListeners;

/**
 * Generated base class, which implements properties and
 * associations for the domain object.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
 * </pre>
 *
 */
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public abstract class RouteSpecificationBase extends AbstractDomainObject {
    @NotNull
    private DateTime arrivalDeadline;
    @NotNull
    private Location origin;
    @NotNull
    private Location destination;

    protected RouteSpecificationBase() {
    }

    public RouteSpecificationBase(DateTime arrivalDeadline, Location origin,
        Location destination) {
        super();
        Validate.notNull(arrivalDeadline);
        this.arrivalDeadline = arrivalDeadline;
        this.origin = origin;
        this.destination = destination;
    }

    public DateTime getArrivalDeadline() {
        return arrivalDeadline;
    }

    /**
     * Creates a copy of this instance, but with another arrivalDeadline.
     */
    public RouteSpecification withArrivalDeadline(DateTime arrivalDeadline) {
        if (EqualsHelper.equals(arrivalDeadline, getArrivalDeadline())) {
            return (RouteSpecification) this;
        }
        return new RouteSpecification(arrivalDeadline, getOrigin(),
            getDestination());
    }

    public Location getOrigin() {
        return origin;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setOrigin(Location origin) {

        // it must be possible to set null when deleting objects
        if ((origin != null) && (this.origin != null) &&
              !this.origin.equals(origin)) {
            throw new IllegalArgumentException(
                "Not allowed to change the origin reference.");
        }
        this.origin = origin;
    }

    /**
     * Creates a copy of this instance, but with another origin.
     */
    public RouteSpecification withOrigin(Location origin) {
        if (EqualsHelper.equals(origin, getOrigin())) {
            return (RouteSpecification) this;
        }
        return new RouteSpecification(getArrivalDeadline(), origin,
            getDestination());
    }

    public Location getDestination() {
        return destination;
    }

    /**
     * This reference can't be changed. Use constructor to assign value.
     * However, some tools need setter methods and sometimes the
     * referred object is not available at construction time. Therefore
     * this method is visible, but the actual reference can't be changed
     * once it is assigned.
     */
    public void setDestination(Location destination) {

        // it must be possible to set null when deleting objects
        if ((destination != null) && (this.destination != null) &&
              !this.destination.equals(destination)) {
            throw new IllegalArgumentException(
                "Not allowed to change the destination reference.");
        }
        this.destination = destination;
    }

    /**
     * Creates a copy of this instance, but with another destination.
     */
    public RouteSpecification withDestination(Location destination) {
        if (EqualsHelper.equals(destination, getDestination())) {
            return (RouteSpecification) this;
        }
        return new RouteSpecification(getArrivalDeadline(), getOrigin(),
            destination);
    }
}
