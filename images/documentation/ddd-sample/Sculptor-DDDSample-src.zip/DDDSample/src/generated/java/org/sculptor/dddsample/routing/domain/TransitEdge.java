package org.sculptor.dddsample.routing.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.validator.NotNull;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
*
* Value object representing TransitEdge.
*/
@Entity
@Table(name = "TRANSITEDGE")
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public class TransitEdge extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "CARRIERMOVEMENTID", nullable = false, length = 100)
    @NotNull
    private String carrierMovementId;
    @Column(name = "FROMUNLOCODE", nullable = false, length = 100)
    @NotNull
    private String fromUnLocode;
    @Column(name = "TOUNLOCODE", nullable = false, length = 100)
    @NotNull
    private String toUnLocode;
    @Column(name = "UUID", nullable = false, length = 255, unique = true)
    private String uuid;

    protected TransitEdge() {
    }

    public TransitEdge(String carrierMovementId, String fromUnLocode,
        String toUnLocode) {
        super();
        Validate.notNull(carrierMovementId);
        this.carrierMovementId = carrierMovementId;
        Validate.notNull(fromUnLocode);
        this.fromUnLocode = fromUnLocode;
        Validate.notNull(toUnLocode);
        this.toUnLocode = toUnLocode;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public String getCarrierMovementId() {
        return carrierMovementId;
    }

    /**
     * Creates a copy of this instance, but with another carrierMovementId.
     */
    public TransitEdge withCarrierMovementId(String carrierMovementId) {
        if (EqualsHelper.equals(carrierMovementId, getCarrierMovementId())) {
            return this;
        }
        return new TransitEdge(carrierMovementId, getFromUnLocode(),
            getToUnLocode());
    }

    public String getFromUnLocode() {
        return fromUnLocode;
    }

    /**
     * Creates a copy of this instance, but with another fromUnLocode.
     */
    public TransitEdge withFromUnLocode(String fromUnLocode) {
        if (EqualsHelper.equals(fromUnLocode, getFromUnLocode())) {
            return this;
        }
        return new TransitEdge(getCarrierMovementId(), fromUnLocode,
            getToUnLocode());
    }

    public String getToUnLocode() {
        return toUnLocode;
    }

    /**
     * Creates a copy of this instance, but with another toUnLocode.
     */
    public TransitEdge withToUnLocode(String toUnLocode) {
        if (EqualsHelper.equals(toUnLocode, getToUnLocode())) {
            return this;
        }
        return new TransitEdge(getCarrierMovementId(), getFromUnLocode(),
            toUnLocode);
    }

    /**
     * This domain object doesn't have a natural key
     * and this random generated identifier is the
     * unique identifier for this domain object.
     */
    public String getUuid() {

        // lazy init of UUID
        if (uuid == null) {
            uuid = java.util.UUID.randomUUID().toString();
        }
        return uuid;
    }

    @SuppressWarnings("unused")
    @PrePersist
    private void initUuid() {
        getUuid();
    }

    /**
     * This method is used by equals and hashCode.
     * @return {{@link #getUuid}
     */
    public Object getKey() {
        return getUuid();
    }
}
