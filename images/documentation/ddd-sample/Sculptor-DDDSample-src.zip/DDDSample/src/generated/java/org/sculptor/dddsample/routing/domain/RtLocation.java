package org.sculptor.dddsample.routing.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.validator.NotNull;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
*
* Value object representing RtLocation.
*/
@Entity
@Table(name = "RTLOCATION")
@EntityListeners({org.hibernate.validator.event.JPAValidateListener.class
})
public class RtLocation extends AbstractDomainObject {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;
    @Column(name = "UNLOCODE", nullable = false, length = 100, unique = true)
    @NotNull
    private String unlocode;

    protected RtLocation() {
    }

    public RtLocation(String unlocode) {
        super();
        Validate.notNull(unlocode);
        this.unlocode = unlocode;
    }

    public Long getId() {
        return id;
    }

    /**
     * The id is not intended to be changed or assigned manually, but
     * for test purpose it is allowed to assign the id.
     */
    protected void setId(Long id) {
        if ((this.id != null) && !this.id.equals(id)) {
            throw new IllegalArgumentException(
                "Not allowed to change the id property.");
        }
        this.id = id;
    }

    public String getUnlocode() {
        return unlocode;
    }

    /**
     * Creates a copy of this instance, but with another unlocode.
     */
    public RtLocation withUnlocode(String unlocode) {
        if (EqualsHelper.equals(unlocode, getUnlocode())) {
            return this;
        }
        return new RtLocation(unlocode);
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getUnlocode}
     */
    public Object getKey() {
        return getUnlocode();
    }
}
