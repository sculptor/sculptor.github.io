package org.sculptor.dddsample.carrier.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.carrier.domain.CarrierMovement}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface CarrierMovementNames {
    public static final String ID = "id";
    public static final String CARRIERMOVEMENTID = "carrierMovementId";
    public static final String FROM = "from";
    public static final String TO = "to";
}
