package org.sculptor.dddsample.carrier.accessimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindByKeysAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaFindByKeysAccessImpl;
import org.fornax.cartridges.sculptor.framework.accessimpl.jpa.JpaSaveAccessImpl;

import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.repositoryimpl.CarrierMovementAccessFactory;

import org.springframework.stereotype.Component;

/**
 * <p>
 * Concrete Factory that creates CarrierMovement access objects.
 * It injects the {@link javax.persistence.EntityManager}
 * into each created access object
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
@Component("carrierMovementAccessFactory")
public class CarrierMovementAccessFactoryImpl
    extends CarrierMovementAccessFactory {
    public FindByKeysAccess<CarrierMovement> createFindByKeysAccess() {
        JpaFindByKeysAccessImpl<CarrierMovement> ao =
            new JpaFindByKeysAccessImpl<CarrierMovement>(getPersistentClass());
        ao.setEntityManager(getEntityManager());

        return ao;
    }

    public SaveAccess<CarrierMovement> createSaveAccess() {
        JpaSaveAccessImpl<CarrierMovement> ao =
            new JpaSaveAccessImpl<CarrierMovement>();
        ao.setEntityManager(getEntityManager());

        return ao;
    }
}
