package org.sculptor.dddsample.cargo.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.cargo.domain.DeliveryHistory}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface DeliveryHistoryNames {
    public static final String EVENTS = "events";
}
