package org.sculptor.dddsample.carrier.domain;

import org.apache.commons.lang.Validate;

import org.fornax.cartridges.sculptor.framework.domain.AbstractDomainObject;
import org.fornax.cartridges.sculptor.framework.util.EqualsHelper;

import org.hibernate.validator.NotNull;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
*
* BasicType for CarrierMovementId.
*/
@Embeddable
public class CarrierMovementId extends AbstractDomainObject {
    @Column(name = "", nullable = false, length = 100, unique = true)
    @NotNull
    private String identifier;

    protected CarrierMovementId() {
    }

    public CarrierMovementId(String identifier) {
        super();
        Validate.notNull(identifier);
        this.identifier = identifier;
    }

    public String getIdentifier() {
        return identifier;
    }

    /**
     * Creates a copy of this instance, but with another identifier.
     */
    public CarrierMovementId withIdentifier(String identifier) {
        if (EqualsHelper.equals(identifier, getIdentifier())) {
            return this;
        }
        return new CarrierMovementId(identifier);
    }

    /**
     * This method is used by equals and hashCode.
     * @return {@link #getIdentifier}
     */
    public Object getKey() {
        return getIdentifier();
    }
}
