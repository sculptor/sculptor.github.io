package org.sculptor.dddsample.cargo.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.domain.CargoRepository;
import org.sculptor.dddsample.cargo.domain.HandlingEventRepository;
import org.sculptor.dddsample.cargo.serviceapi.HandlingEventService;
import org.sculptor.dddsample.carrier.domain.CarrierMovement;
import org.sculptor.dddsample.carrier.domain.CarrierMovementId;
import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;
import org.sculptor.dddsample.carrier.serviceapi.CarrierService;
import org.sculptor.dddsample.location.domain.Location;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;
import org.sculptor.dddsample.location.serviceapi.LocationService;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of HandlingEventService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("handlingEventService")
 * </pre>
 *
 */
public abstract class HandlingEventServiceImplBase
    implements HandlingEventService {
    private static final Log LOG =
        LogFactory.getLog(HandlingEventServiceImplBase.class);
    private CargoRepository cargoRepository;
    private HandlingEventRepository handlingEventRepository;
    private CarrierService carrierService;
    private LocationService locationService;

    public HandlingEventServiceImplBase() {
    }

    protected CargoRepository getCargoRepository() {
        return cargoRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCargoRepository(CargoRepository cargoRepository) {
        this.cargoRepository = cargoRepository;
    }

    protected HandlingEventRepository getHandlingEventRepository() {
        return handlingEventRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setHandlingEventRepository(
        HandlingEventRepository handlingEventRepository) {
        this.handlingEventRepository = handlingEventRepository;
    }

    protected CarrierService getCarrierService() {
        return carrierService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCarrierService(CarrierService carrierService) {
        this.carrierService = carrierService;
    }

    protected LocationService getLocationService() {
        return locationService;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setLocationService(LocationService locationService) {
        this.locationService = locationService;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.carrier.serviceapi.CarrierService#find}
     */
    protected CarrierMovement findCarrierMovement(ServiceContext ctx,
        CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException {
        return carrierService.find(ctx, carrierMovementId);

    }

    /**
     * Delegates to {@link org.sculptor.dddsample.location.serviceapi.LocationService#find}
     */
    protected Location findLocation(ServiceContext ctx, UnLocode unLocode)
        throws LocationNotFoundException {
        return locationService.find(ctx, unLocode);

    }
}
