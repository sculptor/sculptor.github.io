package org.sculptor.dddsample.cargo.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.domain.Itinerary;
import org.sculptor.dddsample.cargo.domain.RouteSpecification;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;

import java.util.List;

/**
 * Generated interface for the Service RoutingService.
 */
public interface RoutingService {
    public static final String BEAN_ID = "routingService";

    /**
    * A list of itineraries that satisfy the specification. May be an empty list if no route is found.
    */
    public List<Itinerary> fetchRoutesForSpecification(ServiceContext ctx,
        RouteSpecification routeSpecification) throws LocationNotFoundException;
}
