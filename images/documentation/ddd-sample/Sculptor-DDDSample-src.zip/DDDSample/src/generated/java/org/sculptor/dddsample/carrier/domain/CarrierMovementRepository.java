package org.sculptor.dddsample.carrier.domain;

import org.sculptor.dddsample.carrier.exception.CarrierMovementNotFoundException;

/**
 * Generated interface for Repository for CarrierMovement
 */
public interface CarrierMovementRepository {
    public static final String BEAN_ID = "carrierMovementRepository";

    public CarrierMovement find(CarrierMovementId carrierMovementId)
        throws CarrierMovementNotFoundException;

    public CarrierMovement save(CarrierMovement entity);
}
