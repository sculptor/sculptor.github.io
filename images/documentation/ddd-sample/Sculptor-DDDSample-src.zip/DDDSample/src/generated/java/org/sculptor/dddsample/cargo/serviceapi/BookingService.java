package org.sculptor.dddsample.cargo.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.domain.Itinerary;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;
import org.sculptor.dddsample.location.domain.UnLocode;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;

import java.util.List;

/**
 * Cargo booking service.
 */
public interface BookingService {
    public static final String BEAN_ID = "bookingService";

    /**
    * Registers a new cargo in the tracking system, not yet routed.
    */
    public TrackingId bookNewCargo(ServiceContext ctx, UnLocode origin,
        UnLocode destination) throws LocationNotFoundException;

    /**
    * Requests a list of itineraries describing possible routes for this cargo.
    */
    public List<Itinerary> requestPossibleRoutesForCargo(ServiceContext ctx,
        TrackingId trackingId)
        throws CargoNotFoundException, LocationNotFoundException;

    /**
    * Assigns a cargo to route.
    */
    public void assignCargoToRoute(ServiceContext ctx, TrackingId trackingId,
        Itinerary itinerary) throws CargoNotFoundException;
}
