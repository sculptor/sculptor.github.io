package org.sculptor.dddsample.cargo.serviceapi;

import org.fornax.cartridges.sculptor.framework.errorhandling.ServiceContext;

import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;

/**
 * Generated interface for the Service TrackingService.
 */
public interface TrackingService {
    public static final String BEAN_ID = "trackingService";

    /**
    * Track a particular cargo.
    */
    public Cargo track(ServiceContext ctx, TrackingId trackingId)
        throws CargoNotFoundException;

    /**
    * Inspect cargo and send relevant notifications to interested parties,
    * for example if a cargo has been misdirected, or unloaded
    * at the final destination.
    */
    public void inspectCargo(ServiceContext ctx, TrackingId trackingId)
        throws CargoNotFoundException;
}
