package org.sculptor.dddsample.cargo.domain;


/**
 * This generated interface defines constants for all
 * attributes and associatations in
 * {@link org.sculptor.dddsample.cargo.domain.RouteSpecification}.
 * <p>
 * These constants are useful for example when building
 * criterias.
 */
public interface RouteSpecificationNames {
    public static final String ARRIVALDEADLINE = "arrivalDeadline";
    public static final String ORIGIN = "origin";
    public static final String DESTINATION = "destination";
}
