package org.sculptor.dddsample.cargo.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByIdAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.PopulateAssociationsAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;
import org.fornax.cartridges.sculptor.framework.domain.AssociationSpecification;

import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.CargoRepository;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Generated base class for implementation of Repository for Cargo
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Repository("cargoRepository")
 * </pre>
 *
 */
public abstract class CargoRepositoryBase implements CargoRepository {

    /**
     * Reference to the access object factory.
     */
    private CargoAccessFactory cargoAccessFactory;

    public CargoRepositoryBase() {
    }

    protected CargoAccessFactory getCargoAccessFactory() {
        return cargoAccessFactory;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCargoAccessFactory(CargoAccessFactory cargoAccessFactory) {
        this.cargoAccessFactory = cargoAccessFactory;
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.cargo.repositoryimpl.FindCargoAccessObject}
     */
    public Cargo find(TrackingId trackingId) throws CargoNotFoundException {
        FindCargoAccessObject ao =
            cargoAccessFactory.createFindCargoAccessObject();
        ao.setTrackingId(trackingId);
        ao.execute();
        return ao.getResult();
    }

    /**
     * Delegates to {@link org.sculptor.dddsample.cargo.repositoryimpl.DeleteOrphanItineraryAccess}
     */
    protected void deleteOrphanItinerary() {
        DeleteOrphanItineraryAccess ao =
            cargoAccessFactory.createDeleteOrphanItineraryAccess();
        ao.execute();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.PopulateAssociationsAccess}
     */
    protected Cargo populateAssociations(Cargo entity,
        AssociationSpecification associationSpecification)
        throws CargoNotFoundException {
        PopulateAssociationsAccess<Cargo> ao =
            cargoAccessFactory.createPopulateAssociationsAccess();
        ao.setEntity(entity);
        ao.setAssociationSpecification(associationSpecification);

        ao.execute();

        if (ao.getResult() == null) {
            throw new CargoNotFoundException("No Cargo found with entity: " +
                entity);
        }

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess}
     */
    public List<Cargo> findAll() {
        FindAllAccess<Cargo> ao = cargoAccessFactory.createFindAllAccess();

        ao.execute();

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess}
     */
    public Cargo save(Cargo entity) {
        SaveAccess<Cargo> ao = cargoAccessFactory.createSaveAccess();
        ao.setEntity(entity);

        ao.execute();

        return ao.getResult();
    }

    /**
     * Delegates to {@link org.fornax.cartridges.sculptor.framework.accessapi.FindByIdAccess}
     */
    protected Cargo findById(Long id) throws CargoNotFoundException {
        FindByIdAccess<Cargo, Long> ao =
            cargoAccessFactory.createFindByIdAccess();
        ao.setId(id);

        ao.execute();

        if (ao.getResult() == null) {
            throw new CargoNotFoundException("No Cargo found with id: " + id);
        }

        return ao.getResult();
    }

    public abstract Cargo find(TrackingId trackingId,
        boolean loadDeliveryHistory) throws CargoNotFoundException;

    public abstract TrackingId nextTrackingId();

    public abstract void detachItineray(Cargo cargo);
}
