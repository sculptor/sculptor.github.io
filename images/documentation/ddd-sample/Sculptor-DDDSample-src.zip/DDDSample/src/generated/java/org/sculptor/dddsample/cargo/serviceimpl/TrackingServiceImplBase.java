package org.sculptor.dddsample.cargo.serviceimpl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.sculptor.dddsample.cargo.domain.CargoRepository;
import org.sculptor.dddsample.cargo.serviceapi.TrackingService;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * Generated base class for implementation of TrackingService.
 * <p>Make sure that subclass defines the following annotations:
 * <pre>
   @org.springframework.stereotype.Service("trackingService")
 * </pre>
 *
 */
public abstract class TrackingServiceImplBase implements TrackingService {
    private static final Log LOG =
        LogFactory.getLog(TrackingServiceImplBase.class);
    private CargoRepository cargoRepository;

    public TrackingServiceImplBase() {
    }

    protected CargoRepository getCargoRepository() {
        return cargoRepository;
    }

    /**
     * Dependency injection
     */
    @Autowired
    public void setCargoRepository(CargoRepository cargoRepository) {
        this.cargoRepository = cargoRepository;
    }
}
