package org.sculptor.dddsample.carrier.exception;

import org.fornax.cartridges.sculptor.framework.errorhandling.ApplicationException;

import java.io.Serializable;

public class CarrierMovementNotFoundException extends ApplicationException {
    private static final String ERROR_CODE =
        CarrierMovementNotFoundException.class.getName();

    public CarrierMovementNotFoundException(String m) {
        super(ERROR_CODE, m);
    }

    public CarrierMovementNotFoundException(String m,
        Serializable messageParameter) {
        super(ERROR_CODE, m);
        setMessageParameters(new Serializable[] { messageParameter });
    }

    public CarrierMovementNotFoundException(String m,
        Serializable[] messageParameters) {
        super(ERROR_CODE, m);
        setMessageParameters(messageParameters);
    }
}
