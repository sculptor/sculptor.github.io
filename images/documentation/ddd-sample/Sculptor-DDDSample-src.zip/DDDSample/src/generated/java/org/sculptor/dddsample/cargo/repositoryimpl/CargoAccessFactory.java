package org.sculptor.dddsample.cargo.repositoryimpl;

import org.fornax.cartridges.sculptor.framework.accessapi.FindAllAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.FindByIdAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.PopulateAssociationsAccess;
import org.fornax.cartridges.sculptor.framework.accessapi.SaveAccess;

import org.sculptor.dddsample.cargo.domain.Cargo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * <p>
 * Abstract Factory that defines factory methods for Cargo
 * access objects. It holds the concrete factory, which is dependency
 * injected. It also holds the {@link javax.persistence.EntityManager},
 * which is typically injected into each access object by the concrete
 * factory.
 * </p>
 * <p>
 * Abstract factory design pattern.
 * </p>
 */
public abstract class CargoAccessFactory {
    private EntityManager entityManager;

    /**
     * Dependency injection
     */
    @PersistenceContext
    protected void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    protected EntityManager getEntityManager() {
        return entityManager;
    }

    protected Class getPersistentClass() {
        return Cargo.class;
    }

    public abstract PopulateAssociationsAccess<Cargo> createPopulateAssociationsAccess();

    public abstract FindAllAccess<Cargo> createFindAllAccess();

    public abstract SaveAccess<Cargo> createSaveAccess();

    public abstract FindByIdAccess<Cargo, Long> createFindByIdAccess();

    public abstract FindCargoAccessObject createFindCargoAccessObject();

    public abstract DeleteOrphanItineraryAccess createDeleteOrphanItineraryAccess();
}
