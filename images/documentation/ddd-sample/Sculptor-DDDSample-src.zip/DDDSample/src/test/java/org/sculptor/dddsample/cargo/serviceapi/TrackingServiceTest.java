package org.sculptor.dddsample.cargo.serviceapi;

import static org.sculptor.dddsample.location.domain.SampleLocations.HELSINKI;
import static org.sculptor.dddsample.location.domain.SampleLocations.HONGKONG;

import java.util.List;

import org.fornax.cartridges.sculptor.framework.test.AbstractDbUnitJpaTests;
import org.junit.Test;
import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.HandlingEvent;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.cargo.domain.Type;
import org.sculptor.dddsample.cargo.exception.CargoNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.ExpectedException;

/**
 * Spring based transactional test with DbUnit support.
 */
public class TrackingServiceTest extends AbstractDbUnitJpaTests
	implements TrackingServiceTestBase {

	private TrackingService trackingService;

	@Autowired
	public void setTrackingService(TrackingService trackingService) {
		this.trackingService = trackingService;
	}

	protected String getDataSetFile() {
		return "dbunit/TestData.xml";
	}

	@Test
	public void testTrack() throws Exception {
		final Cargo cargo = new Cargo(new TrackingId("FGH"), HONGKONG, HELSINKI);

		// Tested call
		Cargo trackedCargo = trackingService.track(getServiceContext(), new TrackingId("FGH"));
		assertEquals(cargo, trackedCargo);

		List<HandlingEvent> events = trackedCargo.deliveryHistory().eventsOrderedByCompletionTime();
		assertEquals(2, events.size());

		HandlingEvent handlingEvent = events.get(0);
		assertEquals(Type.RECEIVE, handlingEvent.getType());

		handlingEvent = events.get(1);
		assertEquals(Type.LOAD, handlingEvent.getType());
	}

	@Test
	@ExpectedException(CargoNotFoundException.class)
	public void testTrackThrowingCargoNotFoundException() throws CargoNotFoundException {
		trackingService.track(getServiceContext(), new TrackingId("ZZZ"));
	}

	@Test
	public void testInspectCargo() throws Exception {
		trackingService.inspectCargo(getServiceContext(), new TrackingId("FGH"));
	}
}
