package org.sculptor.dddsample.location.domain;

import java.util.List;

import org.fornax.cartridges.sculptor.framework.test.AbstractDbUnitJpaTests;
import org.junit.Test;
import org.sculptor.dddsample.location.exception.LocationNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.test.annotation.ExpectedException;

public class LocationRepositoryTest extends AbstractDbUnitJpaTests {
	private LocationRepository locationRepository;

	@Autowired
	public void setLocationRepository(LocationRepository locationRepository) {
		this.locationRepository = locationRepository;
	}

	protected String getDataSetFile() {
		return "dbunit/TestData.xml";
	}

	@Test
	public void testFind() throws Exception {
		final UnLocode melbourne = new UnLocode("AUMEL");
		Location location = locationRepository.find(melbourne);
		assertNotNull(location);
		assertEquals(melbourne, location.getUnLocode());
	}

	@Test
	@ExpectedException(LocationNotFoundException.class)
	public void testFindThrowingLocationNotFoundException() throws LocationNotFoundException {
		locationRepository.find(new UnLocode("NOLOC"));
	}

	@Test
	public void testFindAll() throws Exception {
		List<Location> allLocations = locationRepository.findAll();
		assertNotNull(allLocations);
		assertEquals(7, allLocations.size());
	}

}
