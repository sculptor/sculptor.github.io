package org.sculptor.dddsample.cargo.serviceapi;

import static org.sculptor.dddsample.location.domain.SampleLocations.HELSINKI;
import static org.sculptor.dddsample.location.domain.SampleLocations.HONGKONG;

import java.util.List;

import org.fornax.cartridges.sculptor.framework.test.AbstractDbUnitJpaTests;
import org.joda.time.DateTime;
import org.junit.Test;
import org.sculptor.dddsample.cargo.domain.Cargo;
import org.sculptor.dddsample.cargo.domain.Itinerary;
import org.sculptor.dddsample.cargo.domain.Leg;
import org.sculptor.dddsample.cargo.domain.RouteSpecification;
import org.sculptor.dddsample.cargo.domain.TrackingId;
import org.sculptor.dddsample.location.domain.Location;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Spring based transactional test with DbUnit support.
 */
public class RoutingServiceTest extends AbstractDbUnitJpaTests
    implements RoutingServiceTestBase {
    private RoutingService routingService;

    @Autowired
    public void setRoutingService(RoutingService routingService) {
        this.routingService = routingService;
    }

    protected String getDataSetFile() {
        return "dbunit/TestData.xml";
    }

    @Test
    public void testFetchRoutesForSpecification() throws Exception {
        TrackingId trackingId = new TrackingId("ABC");
        Cargo cargo = new Cargo(trackingId, HONGKONG, HELSINKI);
        RouteSpecification routeSpecification = RouteSpecification.forCargo(cargo, new DateTime());

        List<Itinerary> candidates = routingService.fetchRoutesForSpecification(getServiceContext(), routeSpecification);
        assertNotNull(candidates);

        for (Itinerary itinerary : candidates) {
            List<Leg> legs = itinerary.getLegs();
            assertNotNull(legs);
            assertFalse(legs.isEmpty());

            // Cargo origin and start of first leg should match
            assertEquals(cargo.getOrigin(), legs.get(0).getFrom());

            // Cargo final destination and last leg stop should match
            Location lastLegStop = legs.get(legs.size() - 1).getTo();
            assertEquals(cargo.getDestination(), lastLegStop);

            for (int i = 0; i < legs.size() - 1; i++) {
                // Assert that all legs are conencted
                assertEquals(legs.get(i).getTo(), legs.get(i + 1).getFrom());
            }
        }
    }
}


