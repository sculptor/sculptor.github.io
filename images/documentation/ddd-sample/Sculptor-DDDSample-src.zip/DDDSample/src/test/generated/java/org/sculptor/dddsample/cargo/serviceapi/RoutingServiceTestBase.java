package org.sculptor.dddsample.cargo.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface RoutingServiceTestBase {
    public void testFetchRoutesForSpecification() throws Exception;
}
