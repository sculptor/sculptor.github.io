package org.sculptor.dddsample.cargo.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface HandlingEventServiceTestBase {
    public void testRegister() throws Exception;
}
