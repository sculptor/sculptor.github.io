package org.sculptor.dddsample.routing.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface GraphTraversalServiceTestBase {
    public void testFindShortestPath() throws Exception;
}
