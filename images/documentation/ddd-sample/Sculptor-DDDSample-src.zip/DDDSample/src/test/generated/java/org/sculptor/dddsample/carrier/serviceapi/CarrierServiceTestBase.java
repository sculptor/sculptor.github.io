package org.sculptor.dddsample.carrier.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface CarrierServiceTestBase {
    public void testFind() throws Exception;

    public void testSave() throws Exception;
}
