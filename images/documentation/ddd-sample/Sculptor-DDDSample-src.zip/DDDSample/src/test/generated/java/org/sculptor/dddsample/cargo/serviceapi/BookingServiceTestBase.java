package org.sculptor.dddsample.cargo.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface BookingServiceTestBase {
    public void testBookNewCargo() throws Exception;

    public void testRequestPossibleRoutesForCargo() throws Exception;

    public void testAssignCargoToRoute() throws Exception;
}
