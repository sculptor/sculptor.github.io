package org.sculptor.dddsample.cargo.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface TrackingServiceTestBase {
    public void testTrack() throws Exception;

    public void testInspectCargo() throws Exception;
}
