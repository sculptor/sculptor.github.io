package org.sculptor.dddsample.location.serviceapi;


/**
 * Definition of test methods to implement.
 */
public interface LocationServiceTestBase {
    public void testFind() throws Exception;
}
